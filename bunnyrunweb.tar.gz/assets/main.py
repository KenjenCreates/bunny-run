import pygame
import random
import os
import asyncio

# ------------------- Initialize -------------------
pygame.init()
pygame.mixer.quit()
pygame.mixer.init()

# Screen settings
width, height = 900, 450
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Bunny Run")

# Colors
BLACK = (0, 0, 0)
SOFT_BLUE = (135, 206, 250)
DARK_GREEN = (47, 143, 95)
CLOUD_WHITE = (255, 255, 255)

# FPS and clock
clock = pygame.time.Clock()
FPS = 60

# Bigger image sizes
bunny_width, bunny_height = int(40*1.5), int(60*1.5)
bush_width, bush_height = int(40*1.5), int(40*1.5)
bird_width, bird_height = int(40*1.5), int(30*1.5)

# Hitbox scale
BUNNY_HITBOX_SCALE = 0.85
BUSH_HITBOX_SCALE = 0.6
BIRD_HITBOX_SCALE = 0.85

# Bunny settings
bunny_x = 125
bunny_y = height - bunny_height - 100
bunny_velocity_y = 0
gravity = 0.8
jump_power = -14
is_jumping = False
jump_count = 0
max_jumps = 2

# Bush settings
bush_speed = 6
bushes = []
min_gap_between_bushes = 150
last_bush_x = width

# Bird settings
bird_speed = 8
birds = []
min_gap_between_birds = 300
last_bird_x = width

# Cloud settings
clouds = []
cloud_speed = 2

# Score
score = 0
high_score = 0
font = pygame.font.SysFont(None, 36)
title_font = pygame.font.SysFont(None, 64)

# Sounds (use OGG for web)
jump_sound = pygame.mixer.Sound("jump_sound.ogg")
explosion_sound = pygame.mixer.Sound("explosion.ogg")
explosion_sound.set_volume(0.4)
ding_sound = pygame.mixer.Sound("ding.ogg")
ding_sound.set_volume(0.7)

# Assets folder
ASSETS = "assets"

# Bunny frames
bunny_frames = []
for i in range(1, 7):
    img = pygame.image.load(os.path.join(ASSETS, f"bunny{i}.png")).convert_alpha()
    img = pygame.transform.scale(img, (bunny_width, bunny_height))
    bunny_frames.append(img)

bunny_frame_index = 0
bunny_frame_counter = 0

# Bush image
bush_img = pygame.image.load(os.path.join(ASSETS, "bush.png")).convert_alpha()
bush_img = pygame.transform.scale(bush_img, (bush_width, bush_height))

# Bird frames
bird_frames = []
for i in range(1, 8):
    img = pygame.image.load(os.path.join(ASSETS, f"bird{i}.png")).convert_alpha()
    img = pygame.transform.scale(img, (bird_width, bird_height))
    img = pygame.transform.flip(img, True, False)
    bird_frames.append(img)

# ------------------- Object creation -------------------
def create_bush():
    global last_bush_x
    bush_x = last_bush_x + random.randint(min_gap_between_bushes, 250)
    bush_y = height - bush_height - 100
    bush_rect = pygame.Rect(
        bush_x + int(bush_width*(1-BUSH_HITBOX_SCALE)/2),
        bush_y + int(bush_height*(1-BUSH_HITBOX_SCALE)/2),
        int(bush_width*BUSH_HITBOX_SCALE),
        int(bush_height*BUSH_HITBOX_SCALE)
    )
    last_bush_x = bush_x
    return bush_rect

def create_cloud():
    cloud_width = random.randint(60, 120)
    cloud_height = random.randint(30, 60)
    cloud_x = random.randint(width, width + 200)
    cloud_y = random.randint(50, 100)
    return pygame.Rect(cloud_x, cloud_y, cloud_width, cloud_height)

def create_bird():
    global last_bird_x
    bird_x = last_bird_x + random.randint(min_gap_between_birds, 400)
    bird_y = random.randint(height - bunny_height - 200, height - bunny_height - 150)
    bird_rect = pygame.Rect(
        bird_x + int(bird_width*(1-BIRD_HITBOX_SCALE)/2),
        bird_y + int(bird_height*(1-BIRD_HITBOX_SCALE)/2),
        int(bird_width*BIRD_HITBOX_SCALE),
        int(bird_height*BIRD_HITBOX_SCALE)
    )
    bird_dict = {"rect": bird_rect, "frame_index": random.randint(0,6), "frame_counter":0}
    last_bird_x = bird_x
    return bird_dict

# ------------------- Draw functions -------------------
def draw_sky_and_clouds():
    screen.fill(SOFT_BLUE)
    for cloud in clouds:
        pygame.draw.ellipse(screen, CLOUD_WHITE, cloud)

def draw_ground():
    pygame.draw.rect(screen, DARK_GREEN, (0, height - 100, width, 100))

def draw_bunny():
    global bunny_frame_index, bunny_frame_counter
    bunny_frame_counter += 1
    if bunny_frame_counter >= 5:
        bunny_frame_counter = 0
        bunny_frame_index = (bunny_frame_index + 1) % len(bunny_frames)
    screen.blit(bunny_frames[bunny_frame_index], (bunny_x, bunny_y))

def draw_bushes():
    for bush in bushes:
        x = bush.x - int((bush_width - bush.width)/2)
        y = bush.y - int((bush_height - bush.height)/2)
        screen.blit(bush_img, (x, y))

def draw_birds():
    for bird in birds:
        bird["frame_counter"] += 1
        if bird["frame_counter"] >= 5:
            bird["frame_counter"] = 0
            bird["frame_index"] = (bird["frame_index"] + 1) % len(bird_frames)
        x = bird["rect"].x - int((bird_width - bird["rect"].width)/2)
        y = bird["rect"].y - int((bird_height - bird["rect"].height)/2)
        screen.blit(bird_frames[bird["frame_index"]], (x, y))

def display_score():
    score_text = font.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (10, 10))

def game_over_screen():
    game_over_text = title_font.render("GAME OVER", True, BLACK)
    score_text = font.render(f"Final Score: {score}", True, BLACK)
    high_score_text = font.render(f"High Score: {high_score}", True, BLACK)
    restart_text = font.render("Tap, click, or press SPACE to Restart", True, BLACK)
    screen.blit(game_over_text,(width//2 - game_over_text.get_width()//2, height//4))
    screen.blit(score_text,(width//2 - score_text.get_width()//2, height//2.6))
    screen.blit(high_score_text,(width//2 - high_score_text.get_width()//2, height//2.2))
    screen.blit(restart_text,(width//2 - restart_text.get_width()//2, height//1.7))

# ------------------- Title screen -------------------
async def animated_title_screen():
    global clouds, bushes, birds, last_bush_x, last_bird_x
    clouds.clear(); bushes.clear(); birds.clear()
    last_bush_x = width; last_bird_x = width
    for _ in range(3): clouds.append(create_cloud())
    for _ in range(2): bushes.append(create_bush())
    for _ in range(1): birds.append(create_bird())
    waiting = True
    while waiting:
        draw_sky_and_clouds()
        draw_ground()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); return
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

        for cloud in clouds[:]:
            cloud.x -= cloud_speed
            if cloud.x < -cloud.width: clouds.remove(cloud); clouds.append(create_cloud())
        for bush in bushes[:]:
            bush.x -= bush_speed//2
            if bush.x < -bush_width: bushes.remove(bush); bushes.append(create_bush())
        draw_bushes()
        for bird in birds[:]:
            bird["rect"].x -= bird_speed//2
            if bird["rect"].x < -bird_width: birds.remove(bird); birds.append(create_bird())
        draw_birds()

        title_text = title_font.render("Bunny Run", True, BLACK)
        start_text = font.render("Tap, click, or press SPACE to Start", True, BLACK)
        jump_text = font.render("Jump twice for a double jump!", True, BLACK)
        screen.blit(title_text, (width//2 - title_text.get_width()//2, height//4))
        screen.blit(start_text, (width//2 - start_text.get_width()//2, height//2))
        screen.blit(jump_text, (width//2 - jump_text.get_width()//2, height//1.7))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

# ------------------- Main game loop -------------------
async def game_loop():
    global bunny_y, bunny_velocity_y, is_jumping, jump_count
    global score, bushes, birds, clouds, last_bird_x, last_bush_x
    global high_score

    bunny_y = height - bunny_height - 100
    bunny_velocity_y = 0
    is_jumping = False
    jump_count = 0
    bushes.clear(); birds.clear(); clouds.clear()
    last_bush_x = width; last_bird_x = width
    score = 0
    last_score_milestone = 0
    game_over = False
    is_falling_after_hit = False

    for _ in range(3): clouds.append(create_cloud())

    running = True
    while running:
        draw_sky_and_clouds()
        draw_ground()

        # --- Input ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if not is_falling_after_hit and not game_over:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and jump_count < max_jumps:
                        bunny_velocity_y = jump_power
                        is_jumping = True
                        jump_count += 1
                        jump_sound.play()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if jump_count < max_jumps:
                        bunny_velocity_y = jump_power
                        is_jumping = True
                        jump_count += 1
                        jump_sound.play()

        # --- Bunny physics ---
        if is_jumping or is_falling_after_hit:
            bunny_velocity_y += gravity
            bunny_y += bunny_velocity_y
            if bunny_y >= height - bunny_height - 100:
                bunny_y = height - bunny_height - 100
                if is_jumping:
                    is_jumping = False
                    jump_count = 0
                elif is_falling_after_hit:
                    is_falling_after_hit = False
                    game_over = True
                    if score > high_score: high_score = score

        # --- Obstacles and clouds ---
        if not is_falling_after_hit and not game_over:
            if random.randint(1,100) <= 2: bushes.append(create_bush())
            if score >= 10 and random.randint(1,200) == 1: birds.append(create_bird())
            for bush in bushes[:]:
                bush.x -= bush_speed
                if bush.x < 0: bushes.remove(bush); score +=1
            for bird in birds[:]:
                bird["rect"].x -= bird_speed
                if bird["rect"].x < 0: birds.remove(bird); score +=1
            for cloud in clouds[:]:
                cloud.x -= cloud_speed
                if cloud.x < -cloud.width: clouds.remove(cloud); clouds.append(create_cloud())
            if score // 10 > last_score_milestone:
                ding_sound.play()
                last_score_milestone = score // 10

        # --- Collision detection ---
        if not is_falling_after_hit and not game_over:
            bunny_rect = pygame.Rect(
                bunny_x + int(bunny_width*(1-BUNNY_HITBOX_SCALE)/2),
                bunny_y + int(bunny_height*(1-BUNNY_HITBOX_SCALE)/2),
                int(bunny_width * BUNNY_HITBOX_SCALE),
                int(bunny_height * BUNNY_HITBOX_SCALE)
            )
            for obj in bushes + birds:
                rect = obj if isinstance(obj, pygame.Rect) else obj["rect"]
                if bunny_rect.colliderect(rect):
                    explosion_sound.play()
                    is_falling_after_hit = True
                    bunny_velocity_y = 0

        # --- Draw everything ---
        draw_bunny(); draw_bushes(); draw_birds(); display_score()
        if game_over: game_over_screen()

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

        if game_over:
            running = False

# ------------------- Main -------------------
async def main():
    await animated_title_screen()
    while True:
        await game_loop()
        # Wait for SPACE to restart
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                    waiting = False
            game_over_screen()
            pygame.display.flip()
            clock.tick(FPS)
            await asyncio.sleep(0)

# Run
asyncio.run(main())